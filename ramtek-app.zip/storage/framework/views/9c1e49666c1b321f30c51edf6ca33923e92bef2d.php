<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('page-title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.pageheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('partials.servicesection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ramtek-app\resources\views/pages/service.blade.php ENDPATH**/ ?>