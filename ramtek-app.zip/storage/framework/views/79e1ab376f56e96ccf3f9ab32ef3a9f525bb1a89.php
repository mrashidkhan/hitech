<?php $__env->startSection('title', 'Automation'); ?>

<?php $__env->startSection('page-title', 'Automation'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.pageheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Automation Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="img-border">
                    <img class="img-fluid" src="<?php echo e(asset('img/software.png')); ?>" alt="">
                </div>
            </div>
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="h-100">
                    <h6 class="section-title bg-white text-start text-primary pe-3">Software Development</h6>
                    <h1 class="display-6 mb-4">Software Development services With <span class="text-primary">10 Years</span> Of Experience</h1>
                    <p>Custom software development is the process of designing, building, integrating, scaling, and upgrading software solutions to address the pressing needs or achieve objectives of your specific business.
                        We at HiTech Network Solutions provide you the solutions best suited to your requirements.</p>

                    <a class="btn btn-primary rounded-pill py-3 px-5" href="<?php echo e(route('service')); ?>">Other Services</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Automation End -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ramtek-app\resources\views/services/softwaredevelopment.blade.php ENDPATH**/ ?>