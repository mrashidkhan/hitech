@extends('layouts.master')

@section('title', 'Team')

@section('page-title', 'Team')

@section('content')

    @include('partials.pageheader')

   @include('partials.teamsection')

@endsection
