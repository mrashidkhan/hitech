@extends('layouts.master')

@section('title', 'Project')

@section('page-title', 'Project')

@section('content')

    @include('partials.pageheader')

   @include('partials.projectsection')

@endsection
