@extends('layouts.master')

@section('title', 'About')

@section('page-title', 'About')

@section('content')

    @include('partials.pageheader')

   @include('partials.aboutsection')

@endsection
