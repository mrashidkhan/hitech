@extends('layouts.master')

@section('title', 'Testimonials')

@section('page-title', 'Testimonials')

@section('content')

    @include('partials.pageheader')

   @include('partials.testimonialsection')

@endsection
